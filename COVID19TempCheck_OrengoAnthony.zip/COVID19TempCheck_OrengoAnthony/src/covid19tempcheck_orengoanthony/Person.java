/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package covid19tempcheck_orengoanthony;
/**
 *
 * @author orengoa0459
 */

public class Person {
    //Fields
    public String firstName;
    public String lastName;
    public String status;
    public String age;
    public String identificationNumber;
    public String phoneNumber;
    
    //Constructors
    public Person()
    {
        firstName = "";
        lastName = "";
        status = "";
        age = "";
        identificationNumber = "";
        phoneNumber = "";
    }   
}

